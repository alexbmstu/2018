package com.example.alexdark.myapplication4;

public class SimpleItem {
    float start;
    float value = 0;

    public SimpleItem(float start, float value) {
        this.start = start;
        this.value = value;
    }
}
