package com.example.alexdark.myapplication4;

public class ActivityItem {
    float start;
    int activity;
    int duration;
    int segments;

    public ActivityItem(float start) {
        this.start = start;
    }
}
