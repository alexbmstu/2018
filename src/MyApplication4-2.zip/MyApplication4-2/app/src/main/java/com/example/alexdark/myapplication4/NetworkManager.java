package com.example.alexdark.myapplication4;

import android.os.AsyncTask;
import android.util.Log;

import com.google.android.gms.fitness.data.DataPoint;
import com.google.android.gms.fitness.data.DataSet;
import com.google.android.gms.fitness.data.Field;

import org.json.JSONObject;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import com.google.gson.Gson;

public class NetworkManager {

    ArrayList<DataSet> nutritionsSet = new ArrayList<DataSet>();
    ArrayList<DataSet> stepSet = new ArrayList<DataSet>();
    ArrayList<DataSet> activitySet = new ArrayList<DataSet>();
    ArrayList<DataSet> pulseSet = new ArrayList<DataSet>();

    public class FitnessItem {
        float start;
        float stop;
        float value = 0;

        public FitnessItem(float start, float stop) {
            this.start = start;
            this.stop = stop;
        }
    }

    public class FitnessContainer {
        String type;
        ArrayList<FitnessItem> items;

        public FitnessContainer() {
            this.items = new ArrayList<FitnessItem>();
        }
    }

    void sendSteps() {
        Log.e("History", "##########################################################");
        Log.e("History", "PrintingSteps");
        FitnessContainer container = new FitnessContainer();
        container.type = "steps";
        for (DataSet dataSet : stepSet) {
            container.items.addAll(showDataSet(dataSet));
        }

        Gson gson = new Gson();
        String json = gson.toJson(container); //convert
        System.out.println(json);
        new SendTask("https://jsonplaceholder.typicode.com/posts",json).execute();
        Log.e("History", "##########################################################");
    }

    private ArrayList<FitnessItem> showDataSet(DataSet dataSet) {


        ArrayList<FitnessItem> items = new ArrayList<FitnessItem>();
        Log.e("History", "Data returned for Data type: " + dataSet.getDataType().getName());
        String str = "";
        str+=dataSet.getDataType().getName();
        str+=dataSet.getDataPoints().size();
        Log.e("History", str);
        DateFormat dateFormat = DateFormat.getDateInstance();
        DateFormat timeFormat = DateFormat.getTimeInstance();

        for (DataPoint dp : dataSet.getDataPoints()) {
            FitnessItem item = new FitnessItem(dp.getStartTime(TimeUnit.MILLISECONDS),dp.getEndTime(TimeUnit.MILLISECONDS));

            Log.e("History", "Data point:");
            Log.e("History", "\tType: " + dp.getDataType().getName());
            Log.e("History", "\tStart: " + dateFormat.format(dp.getStartTime(TimeUnit.MILLISECONDS)) + " " + timeFormat.format(dp.getStartTime(TimeUnit.MILLISECONDS)));
            Log.e("History", "\tEnd: " + dateFormat.format(dp.getEndTime(TimeUnit.MILLISECONDS)) + " " + timeFormat.format(dp.getStartTime(TimeUnit.MILLISECONDS)));
            for(Field field : dp.getDataType().getFields()) {
                Log.e("History", "\tField: " + field.getName() +
                        " Value: " + dp.getValue(field));

                float val = 0;

                try {
                    val = dp.getValue(field).asFloat();
                } catch (Exception ex) { }

                try {
                    val = (float) dp.getValue(field).asInt();
                } catch (Exception ex) { }

                try {
                    val = Float.parseFloat(dp.getValue(field).asString()); ;
                } catch (Exception ex) { }

                item.value = val;
            }
            items.add(item);
        }
        return items;
    }

    private class SendTask extends AsyncTask<Void, Void, Void> {
        String url;
        String json;

        public SendTask(String url, String json) {
            this.url = url;
            this.json = json;
        }

        protected Void doInBackground(Void... params) {
            sendData(url,json);
            return null;
        }
    }

    void sendData(String urlString, String json) {
        URL url;
        URLConnection urlConn;
        DataOutputStream printout;

        try
        {
            url = new URL (urlString);
            urlConn = url.openConnection();
            urlConn.setDoInput (true);
            urlConn.setDoOutput (true);
            urlConn.setUseCaches (false);
            urlConn.setRequestProperty("Content-Type","application/json");
            urlConn.setRequestProperty("Host", "android.schoolportal.gr");
            urlConn.connect();
            printout = new DataOutputStream(urlConn.getOutputStream ());
            printout.writeBytes(URLEncoder.encode(json,"UTF-8"));
            printout.flush ();
            printout.close ();
        } catch(Exception ex) {
            String mes = ex.getLocalizedMessage();
            mes+="";
        }
    }
}

