//
//  ViewController.swift
//  BMSTU2018
//
//  Created by Кирилл Володин on 31/10/2018.
//  Copyright © 2018 Кирилл Володин. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // пульс
    @IBOutlet weak var pulseLabel: UILabel!
    @IBOutlet weak var postPulseButton: UIButton!
    
    // калории
    @IBOutlet weak var caloriesLabel: UILabel!
    @IBOutlet weak var postCaloriesButton: UIButton!
    
    // расстояние
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var postDistanceButton: UIButton!
    
    // медитация
    @IBOutlet weak var meditationLabel: UILabel!
    @IBOutlet weak var postMeditationButoon: UIButton!
    
    private let healthService = HelthService()
    private let apiService = ApiService()
    
    var model = Model()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        updateData()
    }
    
    private func setupUI() {
        setupRoundedButton(postPulseButton)
        setupRoundedButton(postCaloriesButton)
        setupRoundedButton(postDistanceButton)
        setupRoundedButton(postMeditationButoon)
        
        addRightBarItem()
    }
    
    private func addRightBarItem() {
        let button = UIButton(type: .custom)
        let image = UIImage(named: "reload")
        button.setImage(image, for: .normal)
        button.addTarget(self, action: #selector(updateData), for: .touchUpInside)
        let barButtonItem = UIBarButtonItem(customView: button)
        navigationItem.setRightBarButton(barButtonItem, animated: false)
    }
    
    private func setupRoundedButton(_ button: UIButton) {
        button.layer.cornerRadius = 8
        button.clipsToBounds = true
    }
    
    @objc private func updateData() {
        healthService.obtainTodayPulse { [weak self] pulse in
            guard let pulse = pulse else { return }
            self?.pulseLabel.text = "\(pulse) уд/мин"
            self?.model.pulse = pulse
        }
        
        healthService.obtainRecentDistanceWalkingRunning { [weak self] distance in
            self?.distanceLabel.text = "\(distance) м"
            self?.model.distance = distance
        }
        
        healthService.obtainLastDayCalories { [weak self] calories in
            guard let calories = calories else { return }
            self?.caloriesLabel.text = "\(calories) ккал"
            self?.model.calories = calories
        }
        
        healthService.obtainLastDayRest { [weak self] rest in
            self?.meditationLabel.text = "\(rest) мин"
            self?.model.meditation = rest
        }
    }
    
    @IBAction func postPulse(_ sender: UIButton) {
        apiService.post(parameter: .pulse, value: "\(model.pulse)")
    }
    
    @IBAction func postCalories(_ sender: UIButton) {
        apiService.post(parameter: .calories, value: "\(model.calories)")
    }
    
    @IBAction func postDistance(_ sender: UIButton) {
        apiService.post(parameter: .distance, value: "\(model.distance)")
    }
    
    @IBAction func postMeditation(_ sender: UIButton) {
        apiService.post(parameter: .meditation, value: "\(model.meditation)")
    }

}

