//
//  Model.swift
//  BMSTU2018
//
//  Created by Кирилл Володин on 02/11/2018.
//  Copyright © 2018 Кирилл Володин. All rights reserved.
//

import Foundation

struct Model {
    var pulse: Double = 0.0
    var meditation: Int = 0
    var distance: Int = 0
    var calories: Double = 0.0
}
