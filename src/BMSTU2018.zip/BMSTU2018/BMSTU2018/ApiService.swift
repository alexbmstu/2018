//
//  ApiService.swift
//  BMSTU2018
//
//  Created by Кирилл Володин on 02/11/2018.
//  Copyright © 2018 Кирилл Володин. All rights reserved.
//

import Foundation
import Alamofire

enum MedParameter: String {
    case pulse
    case calories
    case meditation
    case distance
}

class ApiService {
    // очередь на которой выполняем запросы
    let queue = DispatchQueue.global(qos: .utility)
    
    // POST запрос
    func post(parameter: MedParameter, value: String?) {
        guard let value = value else { return }
        
        // сюда прописываем URL сервера Raspberry
        let url = "http://172.20.10.2:3000/data"
        
        let parameters: Parameters = [
            "parameter": parameter.rawValue,
            "value": value
        ]
    
        Alamofire.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default).validate()
            .responseJSON(queue: queue) { response in
                switch response.result {
                case .success:
                    print("success")
                case .failure(let error):
                    print(error)
                }
        }
    }
}
