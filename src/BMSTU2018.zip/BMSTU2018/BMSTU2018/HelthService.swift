//
//  HelthService.swift
//  BMSTU2018
//
//  Created by Кирилл Володин on 02/11/2018.
//  Copyright © 2018 Кирилл Володин. All rights reserved.
//

import Foundation
import HealthKit

class HelthService {
    
    private let healthStore = HKHealthStore()
    
    init() {
        if HKHealthStore.isHealthDataAvailable() {
            let allTypes = Set([HKObjectType.workoutType(),
                                HKQuantityType.quantityType(forIdentifier: .distanceWalkingRunning)!,
                                HKQuantityType.quantityType(forIdentifier: .dietaryEnergyConsumed)!,
                                HKObjectType.categoryType(forIdentifier: .mindfulSession)!,
                                HKObjectType.quantityType(forIdentifier: .heartRate)!])
            
            healthStore.requestAuthorization(toShare: allTypes, read: allTypes) { (success, error) in
                if !success {
                    print("error")
                }
            }
        }
    }
    
    func obtainTodayPulse(completion: @escaping (Double?) -> Void) {
        let type = HKQuantityType.quantityType(forIdentifier: .heartRate)!
        
        let now = Date()
        let startOfDay = Calendar.current.startOfDay(for: now)
        let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: now, options: .strictStartDate)
        
        let query = HKStatisticsQuery(
            quantityType: type,
            quantitySamplePredicate: predicate,
            options: .discreteMostRecent) { query, result, error in
                let quantity = result?.mostRecentQuantity()
                let beats = quantity?.doubleValue(for: HKUnit.count().unitDivided(by: HKUnit.minute()))
                DispatchQueue.main.async {
                    completion(beats)
                }
        }
        healthStore.execute(query)
    }
    
    func obtainRecentDistanceWalkingRunning(completion: @escaping (Int) -> Void) {
        let type = HKSampleType.quantityType(forIdentifier: .distanceWalkingRunning)!
        
        let endDay = Date()
        let startDay = Calendar.current.date(byAdding: .day, value: -1, to: endDay)
        let predicate = HKQuery.predicateForSamples(withStart: startDay, end: endDay, options: .strictStartDate)
        
        let query = HKStatisticsQuery(
            quantityType: type,
            quantitySamplePredicate: predicate,
            options: [.cumulativeSum]) { query, statistics, error in
            
                let quantity = statistics?.sumQuantity()
                let value = quantity?.doubleValue(for: HKUnit.meter())
                guard let result = value else { return }
                
                DispatchQueue.main.async {
                    completion(Int(result))
                }
        }
        
        healthStore.execute(query)
    }
    
    func obtainLastDayCalories(completion: @escaping (Double?) -> Void) {
        let type = HKQuantityType.quantityType(forIdentifier: .dietaryEnergyConsumed)!
        
        let now = Date()
        let exactlySevenDaysAgo = Calendar.current.date(byAdding: DateComponents(day: -1), to: now)!
        let startOfSevenDaysAgo = Calendar.current.startOfDay(for: exactlySevenDaysAgo)
        let predicate = HKQuery.predicateForSamples(withStart: startOfSevenDaysAgo, end: now, options: .strictStartDate)
        
        let query = HKStatisticsQuery(
            quantityType: type,
            quantitySamplePredicate: predicate,
            options: []) { query, statistics, error in
                
                let quantity = statistics?.sumQuantity()
                let value = quantity?.doubleValue(for: HKUnit.kilocalorie())
                
                DispatchQueue.main.async {
                    completion(value)
                }
        }
        
        healthStore.execute(query)
    }
    
    func obtainLastDayRest(completion: @escaping (Int) -> Void) {
        let type = HKObjectType.categoryType(forIdentifier: .mindfulSession)!
        
            let sortDescriptor = NSSortDescriptor(
                key: HKSampleSortIdentifierEndDate,
                ascending: false)
        
            let endDate = Date()
            let startDate = endDate.addingTimeInterval(-1.0 * 60.0 * 60.0 * 24.0)
            let predicate = HKQuery.predicateForSamples(
                withStart: startDate,
                end: endDate,
                options: [])
        
            let query = HKSampleQuery(
                sampleType: type,
                predicate: predicate,
                limit: 1,
                sortDescriptors: [sortDescriptor]) { query, result, error in
                    let totalMeditationTime = result?.map(self.calculateTotalTime).reduce(0, { $0 + $1 }) ?? 0
                    let result = Int(totalMeditationTime / 60)
                    DispatchQueue.main.async {
                        completion(result)
                    }
            }
        
            healthStore.execute(query)
    }
    
    func calculateTotalTime(sample: HKSample) -> TimeInterval {
        let totalTime = sample.endDate.timeIntervalSince(sample.startDate)
        return totalTime
    }
    
}
